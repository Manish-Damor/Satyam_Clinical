<?php 

include('./constant/check.php');
require_once('./constant/connect.php');
?>
    
    <div id="main-wrapper">
        
        <div class="header">
            <marquee class="d-lg-none d-block">
                <div class="ml-lg-5 pl-lg-5 ">
                  
                     <b id="ti" class="ml-lg-5 pl-lg-5"></b>
                   
                   
                    </div>
            </marquee>
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                
                <div class="navbar-header">
                    <a class="nav-toggler" href="javascript:void(0)" aria-label="Toggle sidebar menu">
                        <i class="mdi mdi-menu"></i>
                    </a>
                    <a class="sidebartoggler" href="javascript:void(0)" aria-label="Toggle sidebar width">
                        <i class="ti-menu"></i>
                    </a>
                    <a class="navbar-brand" href="index.php">
                        
                         
                        <b><img src="./assets/uploadImage/Logo/logo.jpeg" style="width: 100%;" alt="homepage" class="dark-logo" style="width:100%;height:auto;"/></b>
                       
                    </a>
                </div>
                
                <div class="navbar-collapse">
                    <div class="ml-lg-5 pl-lg-5 d-lg-block d-none">
                  
                     <b id="time" class="ml-lg-5 pl-lg-5"></b>
                   
                   
                    </div>
                    <ul class="navbar-nav my-lg-0 ml-auto">
                        <li class="nav-item nav-translate d-none d-lg-flex">
                            <img src="./assets/uploadImage/Logo/transalation.png" alt="Translate">
                            <div id="google_translate_element"></div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                
                                <img src="./assets/uploadImage/Profile/young-woman-avatar-facial-features-stylish-userpic-flat-cartoon-design-elegant-lady-blue-jacket-close-up-portrait-80474088.jpg" alt="user" class="profile-pic" /></a>
                            <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                                <ul class="dropdown-user">
                                   <?php if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
                                     <li><a href="#"><i class="fa fa-key"></i> Changed Password</a></li>
                                      <li><a href="#"><i class="fa fa-user"></i> Add user</a></li>
                                     <?php }?>
                               
                                    <li><a href="./constant/logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>

        </div>
        <script language="javascript">
var today = new Date();
document.getElementById('ti').innerHTML=today;

var today = new Date();
document.getElementById('time').innerHTML=today;
 </script>