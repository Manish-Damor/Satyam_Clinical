<?php
header('Content-Type: application/json');
require_once 'json_core.php';

$response = [
    "success" => false,
    "data" => null,
    "error" => null
];

$supplierId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
// fallback to direct $_GET when running in CLI or when filter_input not available
if (!$supplierId) {
    if (isset($_GET['id'])) $supplierId = intval($_GET['id']);
}

if (!$supplierId) {
    http_response_code(400);
    $response["error"] = "Invalid supplier ID";
    echo json_encode($response);
    exit;
}

$stmt = $connect->prepare("SELECT * FROM suppliers WHERE supplier_id = ?");
$stmt->bind_param("i", $supplierId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    http_response_code(404);
    $response["error"] = "Supplier not found";
} else {
    $response["success"] = true;
    $response["data"] = $result->fetch_assoc();
}

echo json_encode($response);
$connect->close();
?>
